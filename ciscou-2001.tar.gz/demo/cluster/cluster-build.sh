#! /bin/bash

kind create cluster --name demo --config ./kind-config.yaml
